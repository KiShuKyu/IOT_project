# Pala Note — Continuation Handoff

**Handoff date:** 23 November 2026  
**Project phase:** Software MVP verified; ESP32 hardware integration is next.

This document is intended to be pasted into a new ChatGPT conversation so work can continue without re-investigating completed tasks.

---

## 1. Project identity and working directories

Pala Note is a voice-first personal memory assistant and software-project companion.

Active backend:

```text
D:\Coding\becsain\backend
```

Project registry and generated project workspace:

```text
D:\Coding\PalaProjects\projects.json
D:\Coding\PalaProjects\
```

**Do not modify** this older directory for the active Pala Note work:

```text
D:\Coding\becsain\python
```

The app currently runs locally at:

```text
http://127.0.0.1:5000
```

The user is working on Windows and runs the backend through Flask.

---

## 2. What Pala Note does

### Personal memory

- Browser captures/uploads audio to Flask.
- Gemini transcribes and structures the note into tasks, appointments, and memories.
- Backend uses SHA-256 audio hashing for duplicate detection.
- Supabase stores recording/transcript/item data when configured.
- Saved items can be listed, searched, queried, and returned as spoken answers.

### Project creation

- User records an idea.
- `/api/projects/prepare` sends audio to Gemini and returns transcript, project name, and project brief.
- User reviews/edits and explicitly confirms.
- `/api/projects/generate` starts OpenHands.
- Frontend polls status, retrieves the final report, and requests a spoken completion summary.

### Existing-project recall and conversation

- Manual recall lists projects and loads the selected project's summary.
- Manual recall stores `active_project_slug` and `active_project_name` in Flask session.
- Project Conversation can ask typed and spoken follow-up questions.
- Voice recall can switch to another named project.
- Context can be reset by UI button or supported voice phrase.

---

## 3. Current verified software state

The following have been tested successfully in the latest working session:

| Feature | Result |
|---|---|
| Manual existing-project recall | Passed |
| Typed project follow-up | Passed |
| Voice project follow-up | Passed |
| Flask active-project session | Passed |
| Project switching: To Do List App → Expense Tracker | Passed |
| Correct To Do List App storage key | `faculty_tasks` |
| Correct Expense Tracker storage key | `faculty_expense_transactions` |
| Clear active project context | Passed |
| `/api/project-context` after reset | `{"active": false, "ok": true}` |

The project registry last returned three records:

```text
To Do List App
slug: to-do-list-app
path: D:\Coding\PalaProjects\to-do-list-app

Expense Tracker
slug: expense-tracker
path: D:\Coding\PalaProjects\expense-tracker

Pala Smoke Test 2026 11 23
slug: pala-smoke-test-2026-11-23
path: D:\Coding\PalaProjects\pala-smoke-test-2026-11-23
```

### Project-switching bug and fix

Observed bug: Project Conversation's active label changed to To Do List App, but the answer still contained Expense Tracker-specific source text such as `faculty_expense_transactions`.

What was verified:

- `/api/project-context` showed To Do List App with slug `to-do-list-app`.
- `/api/projects` showed both project records and their distinct paths.
- The problem was narrowed to source selection. Manual recall read the selected project's `index.html`, while follow-up helper `_answer_for_active_project()` used `_read_project_source()`, which recursively collected multiple files. That wider source collection could contaminate the prompt with unrelated code.

The user changed `_answer_for_active_project()` in `backend/app.py` to read only:

```python
Path(project['project_path']) / 'index.html'
```

with UTF-8 decoding, replacement for invalid bytes, and a 30,000-character cap, then pass that source to `gemini.answer_project_question(...)`.

The change was verified after Flask restart:

- To Do List App returned `faculty_tasks`.
- Expense Tracker returned `faculty_expense_transactions`.

Do not revert the helper to recursive source aggregation without implementing project-root isolation and testing it carefully.

### Reset verification

The user clicked **Clear active project** and checked:

`http://127.0.0.1:5000/api/project-context`

Response:

```json
{
  "active": false,
  "ok": true
}
```

This is complete. Do not ask the user to repeat the software switching/reset tests.

---

## 4. Latest known code structure

```text
backend/
├── app.py
├── config.py
├── gemini_service.py
├── supabase_service.py
├── openhands_service.py
├── .env
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

This is the expected core layout; confirm any additional support files from the user's local checkout only when necessary.

Key implementation details:

- Flask loads `.env` from the backend directory.
- `app.secret_key` is read from `FLASK_SECRET_KEY`; startup fails when missing.
- Gemini client is created by `GeminiService` using `Config.GEMINI_API_KEY` and `Config.GEMINI_MODEL`.
- TTS helper uses the Gemini Interactions API with model `gemini-3.8-flash-lite-tts` and voice `Kore`, returning WAV bytes.
- `SupabaseService` supports optional/conditional data storage via its `enabled` state.
- OpenHands integration is encapsulated in `OpenHandsService`.
- Frontend Project Conversation listens for `pala:active-project`, reads `/api/project-context`, posts typed questions to `/api/project-chat`, sends recorded audio to `/api/voice-command`, and clears context through `/api/project-chat/reset`.

### Key routes

```text
GET  /                         Main UI
GET  /api/health               Health/config status
POST /api/audio                Save/analyze a memory recording
GET  /api/items                List saved items
GET  /api/search?q=...         Search memories
POST /api/ask                  Ask from stored memories
POST /api/ask-audio            Ask from memories and create spoken answer
POST /api/tts                  Text-to-speech
POST /api/projects/prepare     Prepare project brief from audio
POST /api/projects/generate    Start OpenHands project generation
GET  /api/projects             List registered projects
GET  /api/projects/<id>/status Poll OpenHands job status
GET  /api/projects/<id>/report Retrieve final report
GET  /api/projects/<id>/spoken-summary Generate spoken completion summary
GET  /api/projects/<slug>/summary Manually recall existing project
GET  /api/project-context      Get current browser's active project
POST /api/project-chat         Typed question about active project
POST /api/project-chat/reset   Clear browser active-project context
POST /api/voice-command        Voice project recall/switch/follow-up/reset
```

---

## 5. Important security warning — address before LAN hardware tests

The current backend's `device_auth_ok()` returns `True` unconditionally. The previous intended implementation is commented out and used `Config.DEVICE_TOKEN` plus the `X-Device-Token` request header.

This means endpoints currently bypass device authentication. Localhost testing has worked, but **do not expose this server to the LAN/ESP32 until authentication is restored and tested**.

Also:

- Keep `GEMINI_API_KEY`, Supabase server key, `FLASK_SECRET_KEY`, and OpenHands Agent Server API key out of frontend code, firmware, Git, and chat.
- Keep `.env` untracked.
- Set `DEBUG=false` before LAN exposure.
- Use Windows Firewall private-network rules only.

A Flask browser session is not automatically shared with an ESP32. The hardware needs a device-specific active-project context or a dedicated endpoint that accepts a validated project identifier. Do not assume a request from the ESP32 has the browser's `active_project_slug` cookie.

---

## 6. What is next: ESP32 hardware integration

The next phase is hardware, not more web UI features.

### Still unknown — ask the user once

1. Exact ESP32 board variant (e.g. ESP32 DevKit V1, ESP32-S3, ESP32-C3).
2. Which microphone module they have.
3. Which amplifier/speaker they have.

The user has not yet provided a board model or a hardware photo. Do not invent a pin map. Ask for a board photo or model first, then give exact wiring.

Candidate components, not yet confirmed as selected/owned:

- ESP32 development board.
- INMP441 I2S microphone.
- MAX98357A I2S amplifier.
- Speaker.
- Breadboard, jumper wires, suitable power supply.

### Planned full round trip

```text
Voice → I2S microphone → ESP32
      → Wi-Fi → Flask backend
      → Gemini transcription + intent + project question
      → Gemini TTS WAV
      → HTTP response → ESP32
      → I2S amplifier → speaker
```

### Suggested sequence

1. Identify board/module models and pins.
2. Wire microphone and verify a short I2S PCM recording.
3. Decide audio sample rate/bit depth/channels and package the captured PCM into a format the backend accepts. Raw microphone PCM is not automatically WAV.
4. Make Flask LAN-reachable; find PC IPv4 using `ipconfig`. ESP32 and PC must be on the same local network. Do not use `127.0.0.1` in firmware.
5. Restore `X-Device-Token` validation before LAN requests.
6. Implement/test an ESP32-facing request/response API. Existing `/api/voice-command` expects a multipart field named `audio`, but its project context is currently browser-session scoped; separate the hardware context from browser state.
7. Return WAV audio and play it via I2S amplifier/speaker.
8. Verify project follow-up, project switch, reset, reconnects, empty/oversized audio, and Gemini/TTS error paths.

### Host/network reminders

- Local browser URL: `http://127.0.0.1:5000`.
- For LAN devices, Flask must bind to a LAN-accessible interface (commonly `0.0.0.0`) and Windows Firewall must allow the chosen port on Private networks.
- ESP32 firmware must use the PC's LAN IPv4 and Flask port, not localhost.
- Use the actual serial port shown by Arduino IDE/Device Manager; COM port is machine-specific.
- Wi-Fi network band compatibility depends on the exact board; confirm for the selected ESP32 model.

---

## 7. Portability requirements for another laptop

When the user asks to move Pala Note to another computer, cover all of these:

- Python version, virtual environment, pinned dependencies.
- Clone/copy the active backend repo; do not confuse it with the old `python` directory.
- Recreate `.env` locally with Gemini key/model, Supabase URL/server key/table, Flask secret, device token, host/port/debug, upload limit, and OpenHands values.
- Never copy secrets into the repo or reveal them in output.
- Install/configure OpenHands Agent Server, model/provider profile, API key, server startup, and backend connectivity.
- Recreate workspace root and ensure all paths in `projects.json` point to real folders.
- Copy registry and projects together; rewrite absolute paths for the new OS.
- Update hardware COM/serial port, Wi-Fi/network IP, I2S pin assignments, and device token after board selection.
- Restore auth and firewall settings before ESP32 testing.

Exact OpenHands environment variable names/startup command must be taken from local `config.py` and `openhands_service.py`; don't make them up.

---

## 8. Interaction preferences for the next assistant

- Continue from the verified state above; do not re-investigate typed/voice follow-up, project switching, or reset.
- User wants to finish quickly and explicitly asked to avoid more unnecessary UI work/features.
- Work one hardware step at a time, but keep the overall sequence efficient.
- Give exact pin mappings only after confirming the board and module model.
- When code needs to change, specify the exact file and exact replacement block. Do not make broad rewrites when a targeted edit is sufficient.
- Ask for the result of a test before proceeding to the next wiring/firmware stage.
- Never ask the user to paste API keys, session secrets, or other secrets.

---

## 9. Suggested opening message for the next chat

> Continue Pala Note from this handoff. The software MVP is verified: manual recall, typed follow-up, voice follow-up, To Do List App/Expense Tracker switching, and active-context reset all passed. The source-selection fix is in `backend/app.py`: project follow-ups read only the selected project's `index.html`, verified by `faculty_tasks` and `faculty_expense_transactions`. Do not touch `D:\Coding\becsain\python`. The next task is ESP32 hardware integration. First identify my exact ESP32 board and available mic/amplifier/speaker, then give board-specific wiring. Before LAN use, restore `device_auth_ok()` because it currently returns True. Remember browser Flask sessions are not automatically shared with the ESP32; design device-scoped context. Keep the scope focused on voice input → Flask/Gemini → spoken output, with no extra UI features.
