# Pala Note

> A voice-first personal memory assistant and project companion. Pala Note captures spoken notes, turns them into structured memories, answers questions from saved memories, and helps create, recall, and discuss software projects.

**Current phase:** Software MVP verified locally; next phase is ESP32 hardware integration.

---

## Contents

1. [Overview](#overview)
2. [Current capabilities](#current-capabilities)
3. [Architecture](#architecture)
4. [Repository and data layout](#repository-and-data-layout)
5. [Backend API](#backend-api)
6. [Configuration and secrets](#configuration-and-secrets)
7. [Run locally](#run-locally)
8. [Project memory and context behaviour](#project-memory-and-context-behaviour)
9. [Security notes](#security-notes)
10. [ESP32 hardware roadmap](#esp32-hardware-roadmap)
11. [Portability checklist](#portability-checklist)
12. [Known limitations and next actions](#known-limitations-and-next-actions)

---

## Overview

Pala Note has two connected roles:

- **Personal memory assistant:** accepts audio, transcribes it, extracts structured items such as tasks, appointments, and memories, and stores them in Supabase when storage is configured.
- **Project assistant:** prepares new software-project briefs from voice input, starts project generation through OpenHands, recalls existing projects, and answers follow-up questions using project source files.

The current local development backend is a Flask application. The browser frontend is served by Flask and communicates with JSON and multipart endpoints. Gemini provides language, audio, and speech-generation capabilities. OpenHands is used for project generation. Supabase is the memory store when configured.

Pala Note's project workspace and registry are separate from the backend source folder.

## Current capabilities

### 1. Voice-note capture and structured memory

The browser can upload a recording to `/api/audio`. The backend:

1. Validates the uploaded audio.
2. Sends it to `GeminiService.analyze_audio()`.
3. Receives a transcript and structured items.
4. Computes a SHA-256 hash of the audio.
5. Saves the transcript and extracted items through `SupabaseService` when Supabase is enabled.
6. Reports duplicate recordings rather than blindly saving the same recording again.

The extracted item structure includes a type, title, summary, optional due/start date-time, and tags. The intended item types are `task`, `appointment`, and `memory`.

### 2. Memory search and answers

- `/api/items` returns saved items.
- `/api/search` searches saved items.
- `/api/ask` retrieves relevant stored memories and asks Gemini to answer using those memories.
- `/api/ask-audio` performs a memory-based answer and generates speech.
- `/api/tts` converts supplied text into a WAV response.

The assistant is instructed not to invent details when the stored memories do not support an answer.

### 3. Voice-driven project creation

The project-generation flow is:

1. The browser records an idea and sends it to `/api/projects/prepare`.
2. Gemini returns a transcript, project name, and project brief.
3. The user reviews and edits the proposed brief.
4. The user explicitly confirms the proposal.
5. `/api/projects/generate` starts an OpenHands job.
6. The frontend polls the job's status endpoint.
7. When generation is complete, the backend retrieves the final report, asks Gemini for a completion summary, and generates a spoken announcement.

Project preparation and project generation are intentionally separate: the coding agent is not started until the user confirms the brief.

### 4. Existing-project recall and conversation

The UI includes **Recall an Existing Project** and **Project Conversation**.

- Manual recall loads the project registry from `/api/projects` and calls `/api/projects/<project_slug>/summary`.
- The summary endpoint saves the selected project slug and name in the browser's signed Flask session.
- `/api/project-context` reports the active project for that browser session.
- `/api/project-chat` answers typed follow-up questions about the active project.
- `/api/voice-command` transcribes a spoken query, supports project switching and context reset phrases, and answers using the active project.
- `/api/project-chat/reset` clears the browser's active project context.

The frontend listens for the `pala:active-project` event to update the Project Conversation active-project label after manual recall.

**Important source-selection fix:** Project Conversation follow-ups must read source from the currently selected project. The project-switching bug was traced to the follow-up source helper reading multiple files recursively, which could pull unrelated content into the prompt. The working change made during the latest session was to have `_answer_for_active_project()` read only the selected project's `index.html`, matching the manual-recall source choice. This change was verified by querying both projects and receiving their own storage keys:

| Project | Verified storage key |
|---|---|
| To Do List App | `faculty_tasks` |
| Expense Tracker | `faculty_expense_transactions` |

Project switching was also verified through `/api/project-context`, and clearing the active project returned `{"active": false, "ok": true}`.

### Verified software status

| Feature | Status |
|---|---|
| Existing-project manual recall | Working |
| Typed project follow-up | Working |
| Voice project follow-up | Working |
| Project context stored in Flask session | Working |
| Switching between To Do List App and Expense Tracker | Verified |
| Clearing active project context | Verified |
| Memory capture and project-generation flows | Existing features; not re-regressed in the final hardware handoff check |
| ESP32 recording and playback | Not yet integrated |

---

## Architecture

```mermaid
flowchart TD
    UI[Browser UI: index.html, app.js, style.css]
    FLASK[Flask backend: app.py]
    GEMINI[GeminiService]
    TTS[Gemini TTS: WAV output]
    DB[SupabaseService / Supabase]
    OH[OpenHands Agent Server]
    REG[projects.json registry]
    WORK[Project folders under PalaProjects]
    ESP[ESP32 device - planned]

    UI -->|HTTP / JSON / multipart audio| FLASK
    FLASK --> GEMINI
    FLASK --> TTS
    FLASK --> DB
    FLASK --> OH
    FLASK --> REG
    REG --> WORK
    ESP -. planned audio upload / response playback .-> FLASK
```

### Main responsibilities

| Component | Responsibility |
|---|---|
| `app.py` | Flask routes, sessions, request validation, service orchestration, response formatting, TTS request handling |
| `gemini_service.py` | Audio analysis, transcription, voice-intent classification, project preparation, project naming/identification, project summaries, project Q&A |
| `supabase_service.py` | Saving, listing, and searching personal memory records; duplicate handling is coordinated by the backend |
| `openhands_service.py` | OpenHands Agent Server integration, project generation, job status, final report retrieval, project registry access |
| `config.py` | Environment-backed application configuration |
| `templates/index.html` | Main browser interface |
| `static/app.js` | Browser recording, API calls, project recall, project chat, audio playback, and UI state |
| `static/style.css` | Browser interface styling |

The exact OpenHands Agent Server configuration keys and internal service implementation should be checked in the local `config.py` and `openhands_service.py` before moving the setup to another machine. Do not guess those names.

---

## Repository and data layout

### Known local paths

```text
D:\Coding\becsain\backend\       Flask backend (active project)
D:\Coding\becsain\python\         Older code directory; do not modify for this project
D:\Coding\PalaProjects\            Generated/existing project workspace
D:\Coding\PalaProjects\projects.json  Project registry
```

The `python` directory is legacy/older code and must not be confused with the active Flask backend. Continue work in `D:\Coding\becsain\backend`.

### Expected backend layout

```text
backend/
├── app.py
├── config.py
├── gemini_service.py
├── supabase_service.py
├── openhands_service.py
├── .env                 # local secrets; never commit
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

Other support files (for example, a dependency file or helper modules) may exist in the local checkout. Confirm the actual directory before creating or renaming anything.

### Project registry entries observed during the latest session

The `/api/projects` endpoint returned three projects:

| Project | Slug | Path |
|---|---|---|
| To Do List App | `to-do-list-app` | `D:\Coding\PalaProjects\to-do-list-app` |
| Expense Tracker | `expense-tracker` | `D:\Coding\PalaProjects\expense-tracker` |
| Pala Smoke Test 2026 11 23 | `pala-smoke-test-2026-11-23` | `D:\Coding\PalaProjects\pala-smoke-test-2026-11-23` |

The registry is the source of project names, slugs, and paths. Do not hardcode these three projects into application logic.

---

## Backend API

The following endpoints are present in the current Flask backend source inspected during the handoff. Use the browser Network tab or the route definitions in `app.py` for exact response details if the implementation changes.

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/` | Serves the main UI |
| `GET` | `/api/health` | Reports backend and Gemini/Supabase configuration status |
| `POST` | `/api/audio` | Processes an uploaded memory recording and stores extracted items when Supabase is enabled |
| `GET` | `/api/items` | Lists saved memory items |
| `GET` | `/api/search?q=...` | Searches saved memory items |
| `POST` | `/api/ask` | Answers from stored memories |
| `POST` | `/api/ask-audio` | Answers from stored memories and returns speech data |
| `POST` | `/api/tts` | Generates a WAV audio response from text |
| `POST` | `/api/projects/prepare` | Transcribes a project idea and creates a draft project brief |
| `POST` | `/api/projects/generate` | Starts OpenHands generation after explicit confirmation |
| `GET` | `/api/projects` | Lists projects from the registry |
| `GET` | `/api/projects/<conversation_id>/status` | Checks OpenHands job status |
| `GET` | `/api/projects/<conversation_id>/report` | Retrieves the final OpenHands report |
| `GET` | `/api/projects/<conversation_id>/spoken-summary` | Generates a spoken completion summary |
| `GET` | `/api/projects/<project_slug>/summary` | Summarizes an existing project and selects it as active in the Flask session |
| `GET` | `/api/project-context` | Returns the active project for the current browser session |
| `POST` | `/api/project-chat` | Answers a typed question about the active project |
| `POST` | `/api/project-chat/reset` | Clears active browser project context |
| `POST` | `/api/voice-command` | Transcribes voice input, handles project recall/switch/follow-up/reset, and returns an answer |

Project-conversation reset phrases currently include variants such as “forget the current project”, “clear project context”, and “reset project context”. Exact phrase matching logic is in `app.py`.

---

## Configuration and secrets

The backend loads `.env` from the backend directory. The Flask app requires `FLASK_SECRET_KEY` at startup; it raises an error if this value is missing.

Configuration properties used by the current backend include:

- `FLASK_SECRET_KEY` — signs Flask session cookies. Generate a strong random value locally; never share it in chat or commit it.
- `GEMINI_API_KEY` — Gemini API key.
- `GEMINI_MODEL` — primary Gemini model used by `GeminiService`.
- `SUPABASE_URL` and the configured Supabase key — Supabase connection. The exact environment variable mapping is defined in `config.py` / `supabase_service.py`.
- `ITEMS_TABLE` — configured memory-items table name.
- `MAX_UPLOAD_MB` — upload limit.
- `DEVICE_TOKEN` — intended device-authentication token; authentication must be restored before hardware/LAN exposure.
- `HOST`, `PORT`, `DEBUG` — Flask bind and run settings.
- OpenHands Agent Server URL/API key/model profile/workspace configuration — use the exact names defined by the local `config.py` and `openhands_service.py`; verify them before setting up another machine.

Example only (not a complete `.env` template; exact variable names depend on the local Config class):

```env
FLASK_SECRET_KEY=generate-a-long-random-secret-locally
GEMINI_API_KEY=your-gemini-api-key
GEMINI_MODEL=your-working-gemini-model
SUPABASE_URL=your-supabase-project-url
# Add the Supabase key variable expected by the local config/service.
# Add DEVICE_TOKEN and the OpenHands Agent Server settings expected by the code.
HOST=127.0.0.1
PORT=5000
DEBUG=true
```

Do not paste real secrets into documentation, GitHub, frontend JavaScript, or ESP32 firmware. The Supabase server-side key must remain on the Python backend.

### Flask secret-key setup

A random key can be generated locally from PowerShell:

```powershell
python -c "import secrets; print(secrets.token_hex(32))"
```

Put the generated value in `backend/.env` as `FLASK_SECRET_KEY=...`. Never send the generated value to anyone.

---

## Run locally

The working local URL observed during development is:

```text
http://127.0.0.1:5000
```

Use the Python interpreter and virtual environment that currently run this backend successfully. Python/package compatibility has been a recurring issue across different Python versions in the broader development environment, so record the working interpreter rather than assuming a version.

PowerShell example:

```powershell
cd D:\Coding\becsain\backend
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

Then install the project's actual pinned dependencies. If a `requirements.txt` exists in the active backend folder, use:

```powershell
pip install -r requirements.txt
```

If it does not exist, inspect the imports and the currently working environment, then create and pin a proper dependency file. Do not blindly copy dependencies from the older `python` directory.

Ensure `backend/.env` contains the required values, especially `FLASK_SECRET_KEY` and `GEMINI_API_KEY`, then run:

```powershell
python app.py
```

Open `http://127.0.0.1:5000` in the browser. Check `http://127.0.0.1:5000/api/health` for backend/Gemini/Supabase status.

---

## Project memory and context behaviour

### Selection flow

1. User enters a project name in **Recall an Existing Project**.
2. Frontend loads the list from `/api/projects` and matches the project name/slug.
3. Frontend requests `/api/projects/<project_slug>/summary`.
4. Backend finds the project in the registry and stores `active_project_slug` and `active_project_name` in the Flask session.
5. Frontend receives the response and emits `pala:active-project` so Project Conversation updates its active-project label.
6. Typed follow-ups call `/api/project-chat`; voice follow-ups call `/api/voice-command`.

### Current selected-source policy

For the current minimal prototype, project follow-up answers should read the selected project's `index.html` only. Do not recursively mix all project directories into a single prompt. The latest local code change was made to align follow-up source selection with manual recall; the successful test keys are listed above.

If projects later need multi-file understanding, implement a project-scoped source manifest or a carefully filtered file collector. It must never include files from a different project's root.

### Session scope caveat

The active project is stored in a Flask browser session. A browser and an ESP32 do not automatically share the same session cookie. Hardware integration must therefore define its own device context mechanism rather than assuming the ESP32 can inherit the browser's active project.

---

## Security notes

**Do not expose the current backend to a network or the internet in its present authentication state.** The current `device_auth_ok()` implementation returns `True` unconditionally. The older intended check is commented out and checks the `X-Device-Token` header against `Config.DEVICE_TOKEN`.

Before ESP32 or LAN use:

1. Restore token validation and test both authorized and unauthorized requests.
2. Keep the Gemini, Supabase, Flask, and OpenHands secrets on the backend only.
3. Use a strong `FLASK_SECRET_KEY` and keep `.env` out of version control.
4. Set `DEBUG=false` for network-accessible operation.
5. Bind to the LAN interface only when required; do not use a public port-forward for the prototype.
6. Restrict Windows Firewall access to the private/local network.

The current local development bypass may be acceptable only for isolated localhost testing. It is not acceptable for a device reachable by other machines.

---

## ESP32 hardware roadmap

**Hardware integration has not started yet.** The exact ESP32 board model and physical components still need to be identified. Do not assume a pinout or wire the board using a generic diagram.

### Planned signal path

```text
I2S microphone
     │ digital audio samples
     ▼
ESP32 ── Wi-Fi / local network ──► Flask backend
                                      │
                                      ▼
                               Gemini transcription
                                      │
                               intent / project Q&A
                                      │
                               Gemini text response
                                      │
                               Gemini TTS (WAV)
                                      │
                                      ▼
ESP32 ◄── audio response over HTTP ───┘
  │
  ▼
I2S amplifier → speaker
```

### Candidate components (not yet confirmed as owned/selected)

- ESP32 development board — exact variant must be confirmed (for example, ESP32 DevKit V1 or ESP32-S3).
- I2S microphone such as INMP441.
- I2S amplifier such as MAX98357A.
- Compatible speaker.
- Breadboard, jumper wires, and a suitable power supply.

### Integration stages

1. Identify the exact ESP32 board and microphone/amplifier modules. Confirm pin labels and voltage requirements from the actual boards.
2. Make and test the I2S microphone wiring and capture a short audio sample.
3. Confirm audio encoding and sample format. The microphone's raw I2S PCM stream is not automatically a WAV file; the firmware must package/encode audio correctly for the backend.
4. Put Flask on a LAN-reachable interface, configure Windows Firewall, and use the computer's Wi-Fi IPv4 address in the ESP32 firmware. `127.0.0.1` / `localhost` on the ESP32 refers to the ESP32 itself, not the computer.
5. Restore device-token authentication before sending requests over Wi-Fi. The old intended request header is `X-Device-Token`.
6. Decide on a device-specific active-project context. Do not rely on the browser's Flask session cookie for hardware context.
7. Send audio to a hardware-facing endpoint and verify transcription/intent/project answer.
8. Return generated WAV audio to the ESP32, decode/play it through the I2S amplifier and speaker.
9. Test repeated recordings, Wi-Fi reconnects, empty/oversized audio, Gemini errors, and context switching.

### Important API design point for hardware

The existing `/api/voice-command` endpoint expects a multipart file field named `audio` and uses Flask session state for the active project. It can inform the hardware design, but it is not yet a finished device protocol. A dedicated hardware endpoint or a device-scoped context store may be needed so the ESP32 can recall/switch projects without a browser cookie. Keep browser-session and device-session state separate unless there is a deliberate reason to share them.

---

## Portability checklist

Use this when moving Pala Note to another laptop.

### Code and Python environment

- [ ] Copy/clone the active repository; use `backend/`, not the older `python/` directory.
- [ ] Record the currently working Python version with `python --version`.
- [ ] Create a fresh virtual environment on the new laptop.
- [ ] Install the pinned backend dependencies from the active backend's dependency file.
- [ ] Record dependency versions after confirming the app starts and core routes work.
- [ ] Confirm `templates/index.html` and `static/` assets are present.

### Secrets and environment

- [ ] Create a new local `backend/.env`; do not copy secrets into Git.
- [ ] Set `FLASK_SECRET_KEY` (generate a fresh random value on the new machine).
- [ ] Set Gemini API key and working model.
- [ ] Set Supabase URL, server-side key, and table configuration.
- [ ] Set `DEVICE_TOKEN` and restore its validation in `device_auth_ok()`.
- [ ] Set OpenHands Agent Server API key, endpoint, model profile, and any required provider configuration using the exact names in the source.
- [ ] Set `HOST`, `PORT`, `DEBUG`, and upload limit as appropriate.

### OpenHands and project workspace

- [ ] Install/configure the OpenHands Agent Server as required by this version of `openhands_service.py`.
- [ ] Recreate or select the required model/provider profile.
- [ ] Start the Agent Server and verify the backend can reach it.
- [ ] Set the workspace root to the new machine's project directory.
- [ ] Copy `projects.json` and the referenced project directories together, or rebuild the registry with valid new paths.
- [ ] Confirm every `project_path` in the registry exists on the new machine.
- [ ] Never assume Windows paths such as `D:\Coding\PalaProjects` will work on macOS/Linux.

### Hardware/network (when ESP32 is added)

- [ ] Select the actual ESP32 board and confirm its Arduino board definition.
- [ ] Select the correct USB serial/COM port.
- [ ] Update Wi-Fi SSID/password in local, uncommitted firmware configuration.
- [ ] Update the backend LAN IP and port in the firmware.
- [ ] Copy the device token into firmware securely; it must match backend configuration.
- [ ] Adjust microphone/amplifier I2S pins to the actual board wiring.
- [ ] Configure firewall rules for the private LAN only.
- [ ] Verify recording format, upload size, response decoding, and speaker playback.

---

## Known limitations and next actions

### Known limitations

- ESP32 hardware is not yet connected; the board model and exact pinout are not known.
- `device_auth_ok()` currently bypasses authentication. Restore it before LAN/hardware exposure.
- Flask active-project state is browser-session scoped; hardware needs a device-scoped alternative.
- The local project registry currently contains Windows absolute paths, which must be updated when moving machines.
- Exact OpenHands Agent Server environment variable names and service startup commands must be confirmed from the local `config.py` and `openhands_service.py`.
- The current project-Q&A source policy reads `index.html` only. This is deliberate for the working prototype and avoids cross-project contamination, but does not provide full multi-file code understanding.
- Gemini can return transient high-demand/server errors. Preserve useful text responses when optional TTS generation fails; avoid treating every 503 as an invalid key or quota problem.

### Immediate next actions

1. Confirm which ESP32 board is available. A clear photo of the board is sufficient to identify the model and pin labels.
2. Confirm which microphone, amplifier, speaker, and power components are available.
3. Produce board-specific wiring and a minimal microphone capture sketch.
4. Build the secure LAN audio request/response path to Flask.
5. Add speaker playback and test the full voice round trip.

**Do not add more UI features before completing the hardware MVP.** Keep the scope focused on the voice input → backend processing → spoken output loop.
